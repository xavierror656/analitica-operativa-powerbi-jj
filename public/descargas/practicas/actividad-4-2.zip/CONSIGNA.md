# 4.2 · Detalle con filtros y trazabilidad

Construir el segundo nivel del reporte y el camino que lleva de un indicador malo en el resumen hasta el evento concreto que lo explica.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- Registros crudos con inicio, fin y fecha_hora
- actividad/recorrido.csv · trazabilidad

## Decisión de implementación

Equipo filtra mantenimiento y exposición; no producción/calidad. El cruce temporal se comprueba explícitamente por fecha y línea, sin crear una relación causal automática.

## Detalle de producción · 30 minutos

1. Crea tabla por fecha operativa, línea, turno y lote.
2. Drillthrough con la misma dim_linea[linea_id] usada en el origen.
3. Comprueba filtros transferidos y retorno; navegación de página sola no transmite una barra seleccionada.

## Eventos por equipo y fecha · 25 minutos

1. Crea página Eventos con dim_equipo[equipo_id] y fecha de dim_calendario como campos de drillthrough.
2. Desde Detalle, una tabla de eventos por equipo aporta el campo al clic derecho.
3. Incluye inicio, fin, causa, duración y afecta_produccion; comprueba al menos dos equipos.

## Sincroniza y vuelve · 15 minutos

1. Configura segmentadores sincronizados por las páginas previstas.
2. Añade botón Atrás y prueba en modo lectura o Ctrl + clic en Desktop.
3. Comprueba que un marcador de vista no restaure datos guardados por accidente.

## Recorre de indicador a registro · 20 minutos

1. Elige L3, segundo trimestre de 2026: resumen → día → equipo → eventos.
2. Consulta calidad del mismo día/línea y sus marcas horarias; no atribuyas al equipo por una relación inexistente.
3. Registra identificadores y tiempos. Deja la hipótesis abierta para Día 5.

## Evidencia

Navegación funcionando del resumen al detalle y al evento.

## Ajustes por nivel

Para profundizar: Agregar una página de detalle de calidad con drill-through por tipo de defecto.

Con apoyo: Construir solo el drill-through de producción y dejar el de mantenimiento para el taller.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 4.2. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
