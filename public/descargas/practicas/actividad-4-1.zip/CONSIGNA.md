# 4.1 · Resumen en una página

Diseña una página ejecutiva cuya situación principal pueda reconocerse en cinco segundos.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** Una copia de A3, recursos/metas.csv y el ejemplo de reporte deficiente de esta presentación.
- **Construye:** Resumen con cinco indicadores, tendencia de OEE y comparación entre líneas.
- **Comprueba:** Otra persona observa cinco segundos y explica qué requiere atención sin ayuda del autor.
- **Entrega:** Practicas_A4_Apellido.pbix con Resumen y actividad/prueba_cinco_segundos.csv.

## Materiales

- Ejemplo de reporte deficiente dentro de las slides
- recursos/metas.csv · umbral, unidad y sentido
- actividad/prueba_cinco_segundos.csv

## Decisión de implementación

La página deficiente es un ejemplo web reproducible y una guía de montaje; no se entrega un PBIX ya construido.

## Audita la página deficiente · 30 minutos

1. Observa el ejemplo deliberadamente mal diseñado de esta actividad.
2. Identifica pastel de doce rebanadas, seis medidores, tabla densa, color sin significado, eje truncado y títulos genéricos.
3. Propón en papel jerarquía, pregunta, visuales y qué requiere atención.

## Construye tu resumen · 50 minutos

1. Tarjetas: OEE, cumplimiento, scrap, disponibilidad y MTTR contra metas didácticas.
2. Tendencia OEE de 18 meses y comparación entre líneas; declara alcance de los indicadores.
3. Titula con un hallazgo válido para los filtros seleccionados; usa un título dinámico o una vista fija explícita.

## Prueba cinco segundos · 10 minutos

1. Otra persona observa la página durante cinco segundos.
2. Oculta la vista y pide que diga qué situación necesita atención y dónde.
3. Registra respuesta y cambio de diseño; no expliques antes.

## Evidencia

Página ejecutiva terminada y el resultado de la prueba de cinco segundos.

## Ajustes por nivel

Para profundizar: Construir títulos dinámicos con una medida de texto que cambie según el filtro.

Con apoyo: Entregar el esqueleto de la página con la ubicación de cada visual ya definida.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 4.1. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
