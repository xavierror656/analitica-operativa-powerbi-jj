# 3.1 · ¿Cuánto va a dar?

Hacer tangible el contexto de filtro. Antes de ejecutar cada medida, los participantes predicen su resultado; el error entre lo que esperaban y lo que salió es lo que construye el concepto.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/predicciones.csv · ocho rondas
- actividad/predicciones.dax · una medida por vez
- Capturas crudas de mantenimiento para Agrupar por

## Decisión de implementación

La etapa A2 no tiene turno en mantenimiento. La octava medida conserva ese alcance; la extensión se hace explícitamente en 3.2.

## Fija la celda antes de predecir · 4 minutos

1. Matriz: dim_linea[linea_id] por dim_turno[turno]. Segmentador: abril de 2026.
2. La celda marcada es L3 / turno 1. Usa estas columnas exactas.
3. Abre actividad/predicciones.csv; ocho rondas de siete minutos completan los 60 minutos iniciales.

## Suma simple · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Piezas ud = SUM(fact_produccion[piezas_producidas])
```

## Sustituir el turno · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Turno 3 ud = CALCULATE([Piezas ud], dim_turno[turno] = "3")
```

## Quitar la línea · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Todas las líneas ud = CALCULATE([Piezas ud], ALL(dim_linea))
```

## Intersectar el turno · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Intersección ud = CALCULATE([Piezas ud], KEEPFILTERS(dim_turno[turno] = "3"))
```

## Filtrar registros · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Registros grandes ud = CALCULATE([Piezas ud], FILTER(fact_produccion, fact_produccion[piezas_producidas] >= 600))
```

## Razón de rechazo · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
Rechazo producción % = DIVIDE(SUM(fact_produccion[piezas_producidas])-SUM(fact_produccion[piezas_buenas]), [Piezas ud])
```

## Variables · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
No buenas ud = VAR Total = [Piezas ud] VAR Buenas = SUM(fact_produccion[piezas_buenas]) RETURN Total-Buenas
```

## MTTR · 7 minutos

1. 2 min: predice el valor de L3 / turno 1 y justifícalo.
2. 3 min: crea la medida y compara con tu predicción.
3. 2 min: explica la discrepancia; MTTR todavía recibe fecha y línea, sin turno.

```dax
MTTR min = DIVIDE(CALCULATE(SUM(fact_mantenimiento[duracion_min]), fact_mantenimiento[tipo]="correctivo", fact_mantenimiento[afecta_produccion]=1), CALCULATE(COUNTROWS(fact_mantenimiento), fact_mantenimiento[tipo]="correctivo", fact_mantenimiento[afecta_produccion]=1))
```

## Explica tus errores · 10 minutos

1. CALCULATE sustituye el filtro de esa columna; KEEPFILTERS conserva su intersección.
2. ALL(dim_linea) quita también área y celda, pero conserva mes y turno.
3. Se evalúa tu explicación, no cuántas predicciones acertaste.

## Contrasta MTTR con Power Query · 20 minutos

1. Filtra correctivos con afecta_produccion=1 y el mismo corte de fecha/línea.
2. Agrupa por equipo: suma minutos y cuenta eventos. Divide total de minutos entre total de eventos.
3. Compara con la media simple de promedios por equipo: ponderan diferente y deben nombrarse distinto.

## Evidencia

Hoja de predicciones. No se califica el número de aciertos sino la explicación de los errores.

## Ajustes por nivel

Para profundizar: Agregar dos medidas extra con REMOVEFILTERS y ALLSELECTED para comparar contra ALL.

Con apoyo: Reducir a las primeras cinco medidas y dedicar el tiempo sobrante a repetir la predicción con otra celda.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 3.1. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
