# 2.2 · Pregúntale al modelo

Aprender a leer el modelo como una fuente de respuestas y, sobre todo, a reconocer cuándo una pregunta no puede contestarse con él. Se trabaja sin DAX, solo con campos arrastrados a tablas y matrices.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/preguntas.csv · 10 preguntas
- actividad/respuestas.csv · registro vacío
- Modelo A2 del mismo caso

## Decisión de implementación

La pregunta de semanas con inhábiles se refiere a las seis fechas festivas indicadas, no a cualquier semana con domingo.

## Prepara la investigación · 5 minutos

1. Formen parejas de áreas distintas.
2. Abran actividad/preguntas.csv y el modelo A2.
3. Usen tablas y matrices; todavía no escriban medidas DAX.

## Responde diez preguntas · 45 minutos

1. Usa dimensiones para agrupar y segmentar; declara periodo, unidad y agregación.
2. Registra la respuesta y el visual que la sostiene en actividad/respuestas.csv.
3. Si no existe una ruta de filtro válida, explica qué dato o relación falta.

## Contrasta con otra pareja · 20 minutos

1. Intercambia respuestas antes de ver la clave del instructor.
2. Si difieren, compara filtros, columnas y sumas frente a conteos.
3. Repite el corte y anota la corrección.

## Defiende lo que no se puede responder · 20 minutos

1. El lote no es dimensión compartida entre hechos.
2. Mantenimiento todavía no tiene turno ni parte; no infieras atribuciones con la línea solamente.
3. Propón una extensión, la regla de negocio y cómo verificarla antes de usarla.

## Evidencia

Hoja con las siete respuestas sustentadas y la justificación escrita de por qué las otras tres no pueden contestarse.

## Ajustes por nivel

Para profundizar: Implementar uno de los cambios propuestos (por ejemplo, derivar el turno del evento de mantenimiento en Power Query) y contestar la pregunta que antes no se podía.

Con apoyo: Resolver juntos con el instructor las dos primeras preguntas antes de trabajar en pareja.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 2.2. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
