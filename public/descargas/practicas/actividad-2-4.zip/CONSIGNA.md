# 2.4 · Auditoría cruzada del modelo

Audita el modelo de otra área, corrige los hallazgos y registra una revisión reproducible.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** El modelo A2 de otra área y actividad/checklist.csv.
- **Construye:** Una auditoría de ocho criterios y una versión corregida del modelo.
- **Comprueba:** El revisor repite los filtros afectados y confirma la cifra total sin filtros.
- **Entrega:** Practicas_A2_Apellido.pbix y checklist.csv con evidencia, revisor, fecha y pendientes.

## Materiales

- actividad/checklist.csv · ocho puntos
- Capturas y archivo A2

## Audita un modelo de otra área · 30 minutos

1. Abre actividad/checklist.csv y revisa sus ocho criterios.
2. Anota evidencia concreta de cada hallazgo: tabla, relación, captura o cifra.
3. No marques conforme un criterio que no hayas probado.

## Corrige o justifica · 45 minutos

1. El autor corrige datos y relaciones en una copia conservando la anterior.
2. Si discrepa, escribe su razón y una prueba reproducible.
3. Recalcula el total y verifica un filtro de cada dimensión.

## Revisa y firma · 15 minutos

1. El revisor repite las pruebas afectadas.
2. Registra veredicto, nombre y fecha; no basta una firma sin resultados.
3. Entrega A2 con el checklist y pendientes explícitos.

## Evidencia

Modelo corregido y checklist revisado por otra área.

## Ajustes por nivel

Para profundizar: Actuar como revisores de un segundo modelo, lo que acerca al participante al nivel 4 de la escala de dominio.

Con apoyo: El instructor acompaña la primera mitad de la auditoría para calibrar el criterio.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 2.4. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
