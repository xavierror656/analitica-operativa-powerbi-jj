# 4.4 · Prueba del lector ciego

Observa a un lector de otra área y corrige los obstáculos que le impiden usar el reporte.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** A4 y actividad/lector.csv.
- **Construye:** Tres preguntas: resumen, detalle y trazabilidad; deja el reporte listo para resolverlas.
- **Comprueba:** El lector responde sin ayuda. Registra tiempo, cifra, contexto y bloqueo; repite la tarea corregida.
- **Entrega:** Practicas_A4_Apellido.pbix y lector.csv con resultados y cambios aplicados.

## Materiales

- actividad/lector.csv · registro de tres preguntas
- Reporte acumulativo A4

## Termina el reporte · 60 minutos

1. Valida las cifras antes de ajustar el diseño.
2. Comprueba resumen, detalle, eventos, navegación y filtros visibles.
3. Escribe tres preguntas: una de resumen, una de detalle y una de trazabilidad.

## Observa sin ayudar · 20 minutos

1. Un lector de otra área responde usando solo el reporte.
2. El autor guarda silencio, cronometra y registra cifra, contexto y bloqueo.
3. Usa actividad/lector.csv; no conviertas la prueba en una opinión de colores.

## Corrige lo observado · 10 minutos

1. Prioriza una interpretación incorrecta o una ruta bloqueada.
2. Registra qué cambió y comprueba la tarea afectada.
3. Entrega A4 y el registro. Si sobra tiempo, repite con un segundo lector.

## Evidencia

Reporte de dos niveles y prueba documentada con lector de otra área.

## Ajustes por nivel

Para profundizar: Hacer la prueba con un segundo lector después de los ajustes y comparar tiempos.

Con apoyo: Reducir la prueba a las preguntas de resumen y detalle.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 4.4. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
