# 3.4 · Fichas y validación de los seis indicadores

Documentar los seis indicadores del grupo de forma que cualquier persona sepa qué miden, cómo se calculan y cómo se validaron.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/fichas.csv · seis indicadores
- actividad/validaciones.csv · tres cortes por indicador

## Decisión de implementación

La tolerancia cero del Word significa ninguna discrepancia conceptual o de conteo. Para números de punto flotante usar 1e-10 antes del formato; no exigir igualdad de cadenas redondeadas.

## Documenta seis indicadores · 45 minutos

1. Completa una ficha por cumplimiento, yield, scrap, disponibilidad, OEE y MTTR.
2. Especifica pregunta, fórmula, unidad, meta didáctica, fuente, trampa y responsable.
3. Señala el cambio de alcance de turno aplicado en 3.2.

## Valida tres cortes · 35 minutos

1. Contrasta una fecha, un turno y una línea con registros crudos limpiados de forma reproducible.
2. Usa los mismos filtros y la misma referencia de estándar en ambos cálculos.
3. Exige igualdad de cantidades y de definiciones; compara razones sin redondeo previo y registra precisión numérica.

## Intercambia una ficha · 10 minutos

1. Otra persona debe explicar el indicador sin preguntar al autor.
2. Corrige ambigüedades y registra su observación.
3. Entrega A3 con fichas y tres cortes; con apoyo puede priorizar tres fichas, registrando las pendientes.

## Evidencia

Evidencia A3: los seis indicadores documentados y validados.

## Ajustes por nivel

Para profundizar: Agregar indicadores propios de su área con su ficha completa.

Con apoyo: Enfocarse en tres indicadores bien documentados y validados en lugar de seis incompletos.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 3.4. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
