# 5.1 · Del dato al hallazgo

Resolver un caso tipo misterio usando el reporte construido en la semana, distinguiendo entre la causa real y una coincidencia que parece causa.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/hipotesis.csv · a favor, en contra, veredicto
- Tu reporte y registros crudos
- Resolución reservada al instructor

## Decisión de implementación

No revelar el equipo ni la causa en los ZIP del alumno. El rastro está en registros ordinarios, no en una columna que señale la solución.

## Investiga antes de la junta · 60 minutos

1. La gerencia observa una caída del OEE de L3 en abril–junio de 2026 frente a enero–marzo de 2026.
2. Registra evidencia a favor y en contra de cada hipótesis, incluidas las descartadas.
3. Comprueba eventos, exposición, producción, arranque y el comportamiento de otras líneas y turnos.

## Comparte el veredicto · 20 minutos

1. Cada equipo expone en un minuto; usa el resto para contrastar resultados.
2. Reconstruye una cifra desde un evento y su periodo.
3. Distingue la causa sembrada en la simulación de lo que los datos observacionales por sí solos prueban.

## Discute la resolución · 10 minutos

1. El instructor revela cómo se construyó la simulación.
2. Revisa qué observación refuta la hipótesis del turno como causa.
3. Registra qué faltaría verificar en una planta real antes de recomendar una acción causal.

## Evidencia

Bitácora de hipótesis con el veredicto del equipo.

## Ajustes por nivel

Para profundizar: Cuantificar el impacto: cuántos puntos de OEE explica el equipo y cuánto quedaría sin explicar.

Con apoyo: Dar una pista a mitad del bloque: revisar los eventos de mantenimiento de la línea en el periodo.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 5.1. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
