# 2.1 · Armar el modelo

Que cada participante construya el esquema estrella sobre el archivo que trae del Día 1 y, antes de hacerlo bien, vea con sus propios ojos cómo una relación mal planteada infla las cifras sin que Power BI marque ningún error.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- crudos/ · diez tablas en CSV
- microcaso/ · tres producciones y dos eventos
- montaje.md · limpieza y 16 relaciones

## Decisión de implementación

La inflación se demuestra con Merge + Expand; corregimos la atribución del Word a la relación muchos a muchos.

## Conecta las capturas del caso · 10 minutos

1. Abre una copia del PBIX del Día 1 y usa la carpeta de este paquete.
2. Combina producción y calidad por separado; verifica la limpieza descrita en montaje.md.
3. Crea una tarjeta de piezas sin filtros y anota el total.

## Observa una relación mal planteada · 15 minutos

1. En una copia, relaciona los dos hechos por fecha y prueba el filtro tipo de mantenimiento.
2. Anota qué fechas y filas quedan seleccionadas; no presupongas que el total aumentará.
3. En el microcaso, combina producción con eventos por fecha y expande: 3 × 2 = 6 filas.

## Explica la diferencia · 10 minutos

1. El microcaso pasa de 600 a 1,200 piezas por expansión de filas.
2. Una relación propaga filtros; no duplica físicamente los registros de la tabla original.
3. Señala qué operación cambió la granularidad y por qué el número parece plausible.

## Construye la estrella · 30 minutos

1. Retira la relación directa y la consulta combinada del microcaso.
2. Crea las 16 relaciones de montaje.md, con claves únicas y filtro dimensión → hecho.
3. Calendario y línea filtran cuatro hechos; parte, turno, defecto y equipo tienen alcances específicos.

## Organiza fechas y claves · 15 minutos

1. Marca dim_calendario[fecha] como tabla de fechas.
2. Comprueba 730 días continuos y ordena nombre_mes por mes.
3. Oculta claves de los hechos; conserva campos legibles de las dimensiones.

## Compara contra la fuente · 10 minutos

1. Limpia todos los filtros: 3,761,757 piezas tras retirar ocho copias exactas.
2. Comprueba también 117,998 rechazadas; guarda una captura con el contexto.
3. Conserva la copia A2 y documenta las rutas de filtros.

## Evidencia

Diagrama y tarjeta sin filtros reconciliada; explicación del microcaso 600 → 1,200.

## Ajustes por nivel

Para profundizar: Discutir si dim_equipo debe relacionarse con dim_linea (copo de nieve) o aplanarse agregando los atributos de línea en la propia dim_equipo, y justificar la decisión.

Con apoyo: Entregar una plantilla con las dimensiones ya cargadas, de modo que solo construyan y verifiquen las relaciones.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 2.1. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
