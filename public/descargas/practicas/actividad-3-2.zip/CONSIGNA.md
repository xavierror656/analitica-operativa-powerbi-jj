# 3.2 · Los indicadores de mi área

Cada área construye los indicadores que usa en su trabajo, y Business Excellence integra el OEE a partir de las medidas de los demás, lo que obliga a revisar el trabajo ajeno.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/medidas.dax · recetario
- recursos/estandares_ingenieria.csv · referencia
- Exposición por equipo y metas didácticas

## Decisión de implementación

OEE solo es posible aquí porque los tiempos son únicos por bloque y los estándares tienen unidad. MTBF cuenta fallas con efecto en producción y utiliza horas-equipo.

## Acuerda nombres y alcance · 10 minutos

1. Crea _Medidas y carpetas Operaciones, Ingeniería y Business Excellence.
2. Aplica el cambio documentado en montaje.md: derivar turno de inicio y crear la relación 17.
3. Usa unidades al final: ud, %, min, h o ud/h; no mezcles horas-equipo con horas de línea.

## Construye los indicadores de tu área · 50 minutos

1. Operaciones: cumplimiento, disponibilidad y productividad. Ingeniería: scrap y MTBF.
2. Business Excellence: rendimiento con SUMX/RELATED, yield y OEE.
3. Compara el corte 06/04/2026, L3, turno 1; contrasta el estándar capturado con la ficha de ingeniería.

## Integra y cuestiona el OEE · 20 minutos

1. OEE = disponibilidad × rendimiento × yield, con el mismo corte y reglas.
2. Si supera 100 %, revisa unidades, tiempos y estándar; nunca recortes la medida a 100 %.
3. Documenta la corrección del catálogo por referencia, vuelve a calcular y conserva evidencia del antes.

## Presenta una validación · 10 minutos

1. Cada área explica un indicador en un minuto; el tiempo restante permite contraste.
2. Expón numerador, denominador y la ruta de filtros.
3. Muestra por qué lote no filtra ambos hechos en Scrap %, aunque un visual devuelva un número.

## Evidencia

Medidas por área, control manual y registro de revisión del estándar. Sin KPI precalculados en los CSV.

## Ajustes por nivel

Para profundizar: Construir el Pareto de defectos con porcentaje acumulado.

Con apoyo: Entregar la fórmula de Rendimiento con SUMX y RELATED como punto de partida.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 3.2. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
