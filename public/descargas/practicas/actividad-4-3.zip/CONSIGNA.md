# 4.3 · Estaciones de interacción y navegación

Aplica interacciones, metas, tooltips, marcadores y navegación al reporte propio.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** A4, actividad/estaciones.csv y recursos/metas.csv.
- **Construye:** Trabaja las cinco estaciones e integra al menos tres funciones en tu reporte.
- **Comprueba:** Prueba filtros antes y después; los marcadores de vista no deben restaurar filtros por accidente.
- **Entrega:** A4 y estaciones.csv con al menos tres funciones, sus pruebas y capturas.

## Materiales

- actividad/estaciones.csv · cinco retos
- recursos/metas.csv
- Tu reporte A4 en construcción

## Interacciones · 15 minutos

1. Prueba filtrar, resaltar y ninguna interacción entre dos visuales; registra la intención.
2. Aplica la función en tu propio reporte y registra una prueba en actividad/estaciones.csv.
3. Prueba filtros antes y después; conserva una captura del resultado.

## Formato contra meta · 15 minutos

1. Usa metas.csv, su unidad y sentido. Los porcentajes se comparan con razones 0–1.
2. Aplica la función en tu propio reporte y registra una prueba en actividad/estaciones.csv.
3. Prueba filtros antes y después; conserva una captura del resultado.

## Tooltip de treinta días · 15 minutos

1. Configura página tooltip para la línea seleccionada y comprueba los últimos 30 días del corte.
2. Aplica la función en tu propio reporte y registra una prueba en actividad/estaciones.csv.
3. Prueba filtros antes y después; conserva una captura del resultado.

## Marcadores y selector · 15 minutos

1. Alterna vista por turno y línea con botones; desactiva Datos si solo cambia la vista.
2. Aplica la función en tu propio reporte y registra una prueba en actividad/estaciones.csv.
3. Prueba filtros antes y después; conserva una captura del resultado.

## Menú y navegación · 15 minutos

1. Crea menú con accesos a Resumen, Detalle y Eventos, incluyendo regreso.
2. Aplica la función en tu propio reporte y registra una prueba en actividad/estaciones.csv.
3. Prueba filtros antes y después; conserva una captura del resultado.

## Comparte la función más útil · 15 minutos

1. Muestra a quien tienes al lado qué pregunta facilita resolver.
2. Explica una limitación y cómo la probaste.
3. Entrega al menos tres funciones aplicadas; las cinco estaciones siguen disponibles.

## Evidencia

Al menos tres de las cinco funciones aplicadas en el reporte propio.

## Ajustes por nivel

Para profundizar: Combinar marcadores y botones en un panel de filtros que se abre y se cierra.

Con apoyo: Completar tres estaciones con calma en lugar de cinco con prisa.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 4.3. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
