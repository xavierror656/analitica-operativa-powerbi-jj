# 2.3 · Detective de relaciones

Diagnostica cuatro fallos de relaciones y demuestra que cada reparación conserva las cifras correctas.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** Las cuatro copias aisladas preparadas por el instructor y actividad/sintomas.csv.
- **Construye:** Cuatro reparaciones documentadas y un modelo con jerarquías, formatos y claves ocultas.
- **Comprueba:** Repite filtros, totales y unicidad antes y después; no mezcles las variantes del laboratorio.
- **Entrega:** Las copias reparadas y actividad/diagnostico.csv con cuatro pruebas antes/después.

## Materiales

- laboratorio/caso-a a caso-d · variantes crudas
- actividad/sintomas.csv · sin causas
- actividad/diagnostico.csv · registro vacío

## Decisión de implementación

Los CSV no pueden guardar relaciones inactivas. El instructor monta ese estado en Desktop. Una clave con espacio puede fallar al empatar y tras Recortar quedar duplicada; no se afirma que duplique automáticamente SUM.

## Investiga cuatro síntomas · 50 minutos

1. Trabaja en cuatro copias aisladas preparadas por el instructor con laboratorio/caso-a a caso-d.
2. Registra síntoma, hipótesis, causa, corrección y comprobación en actividad/diagnostico.csv.
3. Corrige datos en Power Query y estado/dirección de relación en Modelo; no actives bidireccionalidad por ensayo.

## Organiza el modelo reparado · 40 minutos

1. Crea Año > Trimestre > Mes > Semana y Área > Línea > Celda; aclara semanas ISO que cruzan mes.
2. Ordena nombre_mes por mes, aplica formatos y oculta campos técnicos.
3. Repite controles de filas, unicidad y total después de reparar cada copia.

## Evidencia

Cuatro diagnósticos con prueba antes/después y un modelo organizado.

## Ajustes por nivel

Para profundizar: Buscar una quinta falla no anunciada: dejar una relación con filtro bidireccional innecesario que genera ambigüedad, y que la identifiquen por su cuenta.

Con apoyo: Entregar los síntomas de uno en uno, con una pista sobre en qué vista buscar.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 2.3. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
