# Actividad 2.3 · Detective de relaciones

Dataset sintético Prácticas 2025–2026. No mezclar con el ZIP anterior del curso.

Los archivos de crudos son capturas por registro, sin KPI ni modelo resuelto. Contienen espacios en claves, fechas ISO y dd/MM/yyyy y ocho duplicados exactos en cada uno de los tres hechos principales. Se corrigen en Power Query conservando una copia. El estándar de parte se valida con la ficha de ingeniería durante 3.2. No alteres el archivo fuente.

Combina por carpeta una familia de hechos a la vez. Dimensiones y exposición por equipo se cargan como CSV individuales. Los CSV usan coma, UTF-8 y punto decimal.

Continúa tu PBIX de la actividad anterior. Los datos repetidos en cada ZIP permiten recuperar la práctica; no anexes ZIP de distintas actividades entre sí.

Consulta CONSIGNA.md, diccionario.md y montaje.md.
