# 5.3 · Tacha lo que no puedes sostener

Clasifica afirmaciones y reescribe las que exceden la evidencia del modelo.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Tu entrega, paso a paso

- **Abre:** actividad/afirmaciones.csv, actividad/reescrituras.csv y la demostración de verificación del Día 5.
- **Construye:** Clasificación de ocho afirmaciones y tres versiones con dato, periodo, fuente y límite.
- **Comprueba:** Justifica cada categoría. Contrasta piezas y rechazos con Python durante la demostración de 12 minutos.
- **Entrega:** afirmaciones.csv con clasificación final y reescrituras.csv con tres afirmaciones defendibles.

## Materiales

- actividad/afirmaciones.csv · ocho casos
- actividad/reescrituras.csv · tres registros
- actividad/verificar_practicas.py · solo Día 5

## Decisión de implementación

Se conservan las cuatro tareas del Word; la plenaria pasa de 30 a 18 minutos para incluir los 12 minutos de Python solicitados por el usuario.

## Clasifica ocho afirmaciones · 20 minutos

1. Abre actividad/afirmaciones.csv.
2. Elige sustentada, solo correlación, no sustentable con el modelo o uso como registro de calidad.
3. Anota la cifra/filtro o la ausencia de evidencia que justifica tu categoría.

## Contrasta en pareja · 20 minutos

1. Compara sin borrar tu respuesta inicial.
2. Una misma frase puede tener más de un problema: registra categoría principal y matiz.
3. Para una afirmación cuantitativa, reconstruye la cifra antes de aprobarla.

## Debate lo que divide al grupo · 18 minutos

1. Discute causalidad, atribuciones al personal y liberación de lotes.
2. El reporte apoya decisiones; no sustituye registros controlados ni sistemas validados.
3. La clase no demuestra eficacia formal de una acción correctiva.

## Python solo hoy: contrasta un corte · 12 minutos

1. El instructor ejecuta actividad/verificar_practicas.py sobre este ZIP y contrasta piezas y rechazos.
2. Compara el total de piezas y rechazos contra Power BI; no se lee PBIX ni se ejecuta DAX.
3. Sin instalación autorizada, observa la demostración y explica el alcance de la verificación.

## Reescribe tres afirmaciones · 20 minutos

1. Conserva dato, periodo, fuente y límite.
2. Convierte una causa no probada en hipótesis verificable.
3. Entrega clasificación final y tres versiones defendibles.

## Evidencia

Clasificación final y las tres afirmaciones reescritas.

## Ajustes por nivel

Para profundizar: Redactar afirmaciones nuevas para que otra pareja las clasifique.

Con apoyo: Trabajar la clasificación en pareja desde el inicio.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 5.3. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
