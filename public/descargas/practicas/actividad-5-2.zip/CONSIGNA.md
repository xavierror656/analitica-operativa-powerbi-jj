# 5.2 · Presentación en formato de junta

Comunicar un hallazgo como se hace en una junta de producción: corto, con cifra y fuente, y aguantando preguntas.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/pagina_junta.csv · seis campos
- actividad/tarjetas_gerente.csv · cinco preguntas
- actividad/preguntas_recibidas.csv

## Prepara una página de junta · 30 minutos

1. Completa hallazgo, cifra, periodo, fuente, recomendación y lo que todavía no sabemos.
2. Incluye responsable propuesto y verificación, sin prometer mejoras no calculadas.
3. Usa actividad/pagina_junta.csv y prepara el acceso al detalle.

## Ensaya con el gerente escéptico · 50 minutos

1. Diez rondas de cinco minutos: tres de exposición y dos de preguntas.
2. Rota el papel del gerente usando actividad/tarjetas_gerente.csv.
3. Registra pregunta, respuesta y corrección; todos intervienen dentro de su equipo.

## Revisa las preguntas difíciles · 10 minutos

1. Identifica qué cifras o inferencias no pudiste sostener.
2. Ajusta la página y la recomendación.
3. El ensayo es de tres minutos; la presentación final será de siete.

## Evidencia

Página de junta y registro de las preguntas recibidas.

## Ajustes por nivel

Para profundizar: Presentar sin la página, solo con el reporte en pantalla.

Con apoyo: Ensayar una vez con el instructor antes de la ronda.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 5.2. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
