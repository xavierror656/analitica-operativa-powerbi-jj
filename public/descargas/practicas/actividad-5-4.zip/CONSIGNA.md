# 5.4 · Proyecto final integrado

Integrar todo lo de la semana en un reporte que el participante pueda llevar a su área al día siguiente, y defenderlo ante el grupo.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/rubrica.csv · cinco criterios del plan
- actividad/entrega.csv · operación y pendientes

## Decisión de implementación

El Word asigna 40 minutos a hasta seis presentaciones de siete. Ajuste explícito: integración 43, presentaciones 42 y registro 5, manteniendo los 90 minutos.

## Integra el reporte final · 43 minutos

1. Conserva A1–A4 y verifica el archivo acumulativo.
2. Completa rúbrica, hallazgo, limitaciones y plan de entrega.
3. Usa datos sintéticos; un extracto propio solo se usa con autorización formal y preparación suficiente.

## Presenta durante siete minutos · 42 minutos

1. Hasta seis equipos: seis × siete minutos = 42. Fija orden y abre archivos antes del bloque.
2. Integra las preguntas breves dentro de cada turno de siete minutos; no agregues tiempos fuera del bloque.
3. Cada integrante aporta evidencia observable; con menos equipos usa el tiempo restante para retroalimentación.

## Registra A5 · 5 minutos

1. Guarda reporte y rúbrica con pendientes y responsables.
2. Publica solo si la política y permisos lo permiten; de lo contrario entrega PBIX local y exportación.
3. Anota lo realizado realmente, la fecha del dato y el responsable de actualización.

## Evidencia

Reporte A5 integrado y rúbrica individual dentro del trabajo del equipo.

## Ajustes por nivel

Para profundizar: Publicar el reporte con seguridad a nivel de fila por línea, si la política lo permite.

Con apoyo: Presentar el reporte con datos sintéticos aunque haya extracto propio disponible.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 5.4. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
