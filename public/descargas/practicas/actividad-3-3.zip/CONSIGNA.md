# 3.3 · ¿La mejora se sostuvo?

Aplicar la inteligencia de tiempo a la pregunta que trae Business Excellence: demostrar con datos si una mejora se mantuvo o fue un pico.

90 minutos. Caso Prácticas 2025–2026; conservar un único PBIX acumulativo.

## Materiales

- actividad/tiempo.dax · cinco comparaciones
- actividad/conclusion.csv · registro vacío

## Decisión de implementación

El instructor permite ruta autónoma avanzada y refuerza contexto con el resto, tal como pide el plan.

## Construye comparaciones temporales · 20 minutos

1. Usa el calendario marcado y meses completos; copia las medidas del recetario una por una.
2. Construye anterior, variación, YTD, promedio móvil de tres meses y mismo periodo del año anterior.
3. El Scrap YTD es razón de sumas acumuladas; no suma porcentajes mensuales.

## Contrasta L2 y L4 · 40 minutos

1. Grafica Scrap % mensual y promedio móvil de tres meses para las dos líneas.
2. Observa octubre de 2025–junio de 2026 y compara mayo con junio de 2026.
3. Para año anterior usa meses de enero a junio de 2026; 2025 no tiene comparador previo.

## Escribe una conclusión de tres líneas · 20 minutos

1. Incluye cifra, periodo comparado y fuente.
2. Distingue un descenso sostenido de un mes atípico.
3. No atribuyas causalidad a un proyecto real: la historia es sintética y la serie no demuestra causa por sí sola.

## Defiende la comparación · 10 minutos

1. Lee dos o tres conclusiones.
2. Declara si el promedio móvil es media simple de tasas mensuales y por qué no es la tasa conjunta del trimestre.
3. Revisa ventanas incompletas y BLANK; no conviertas meses sin historia en cero.

## Evidencia

Gráfico L2/L4 y conclusión de tres líneas sustentada.

## Ajustes por nivel

Para profundizar: Según la advertencia de la propuesta, este es el bloque para bifurcar: los avanzados trabajan de forma autónoma con la guía escrita y pueden agregar grupos de cálculo para la inteligencia de tiempo.

Con apoyo: Mientras los avanzados trabajan solos, el instructor refuerza contexto de filtro con el resto del grupo antes de entrar al tiempo.

Registrar acompañamiento y criterios pendientes. Reducir temporalmente el alcance no acredita por sí solo la evidencia completa.

## Fuente

Plan_Practicas_PowerBI_Dias2-5.docx, actividad 3.3. Las correcciones técnicas y ajustes de minutos se declaran en esta consigna.
